'use strict';

var usernamePage = document.querySelector('#username-page');
var usernamePageRegister =document.querySelector('#username-page-register');
var chatPage = document.querySelector('#chat-page');
var usernameForm = document.querySelector('#usernameForm');
var usernameRegisterForm = document.querySelector('#usernameRegisterForm');
var messageForm = document.querySelector('#messageForm');
var messageInput = document.querySelector('#message');
var messageArea = document.querySelector('#messageArea');
var connectingElement = document.querySelector('.connecting');

var stompClient = null;
var username = null;
var name = null;
var password = null;

var colors = [
    '#2196F3', '#32c787', '#00BCD4', '#ff5652',
    '#ffc107', '#ff85af', '#FF9800', '#39bbb0'
];

function connect(event) {
	alert('call connect');
    name = document.querySelector('#username').value.trim();
    password = document.querySelector('#password').value.trim();
   //password = $('#password').val();
    alert('hi '+name);
    alert('password'+password);
    if(username != '' && password != ''){
		alert('hi');
		$.ajax({
	    	   type: "post",
	    	   url: "save",
	    	   dataType: "json",  
	    	   data:{username: name , password: password},
	    	   success: function(data){
	    		  alert('success :::: '+data);
	    	    if(data == 1){
	    	    	event.preventDefault();
	    	    	alert('inserted');
	    	    	console.log('hie');
				    //if(username) {
						console.log('username :: '+username);
						alert('usernamePageRegister hidden call');
						usernamePageRegister.classList.add('hidden');
				        alert('usernamePage hidden remove');
				        usernamePage.classList.remove('hidden');
				         alert('chatPage hidden add');
				        chatPage.classList.add('hidden');
				        alert('chatPage hidden add');
				        event.preventDefault();
				        alert('event');
	    	    	//showAll();
	    	    }else{
	    	    	alert('inserting fail');
	    	    	//$('#confirmationDialog').dialog('close');
	    	    	//showAll();
	    	    }
	    	   },
	    	   error: function(){      
	    	    alert('Error while request..');
	    	   }
	    });
	    //alert('success :::: ');
	}else{
		alert('User name and password can not be blank..');
	}
    
	
}

function connect1(event) {
	alert('call connect1');
    username = document.querySelector('#name').value.trim();
    
   //password = $('#password').val();
    alert('hi '+username);
    if(username) {
		console.log('username :: '+username);
		usernamePageRegister.classList.add('hidden');
        usernamePage.classList.add('hidden');
        chatPage.classList.remove('hidden');

        var socket = new SockJS('/websocket');
        stompClient = Stomp.over(socket);

        stompClient.connect({}, onConnected, onError);
    }
	event.preventDefault();
    
	
}


function onConnected() {
    // Subscribe to the Public Topic
    stompClient.subscribe('/topic/public', onMessageReceived);

    // Tell your username to the server
    console.log('onConnected');
    stompClient.send("/app/chat.register",
        {},
        JSON.stringify({sender: username, type: 'JOIN'})
    )

    connectingElement.classList.add('hidden');
}


function onError(error) {
    connectingElement.textContent = 'Web socket have issue please contact administrador.';
    connectingElement.style.color = 'red';
}


function send(event) {
    var messageContent = messageInput.value.trim();

    if(messageContent && stompClient) {
        var chatMessage = {
            sender: username,
            content: messageInput.value,
            type: 'CHAT'
        };

        stompClient.send("/app/chat.send", {}, JSON.stringify(chatMessage));
        messageInput.value = '';
    }
    event.preventDefault();
}


function onMessageReceived(payload) {
    var message = JSON.parse(payload.body);

    var messageElement = document.createElement('li');

    if(message.type === 'JOIN') {
        messageElement.classList.add('event-message');
        message.content = message.sender + ' joined!';
    } else if (message.type === 'LEAVE') {
        messageElement.classList.add('event-message');
        message.content = message.sender + ' left!';
    } else {
        messageElement.classList.add('chat-message');

        var avatarElement = document.createElement('i');
        var avatarText = document.createTextNode(message.sender[0]);
        avatarElement.appendChild(avatarText);
        avatarElement.style['background-color'] = getAvatarColor(message.sender);

        messageElement.appendChild(avatarElement);

        var usernameElement = document.createElement('span');
        var usernameText = document.createTextNode(message.sender);
        usernameElement.appendChild(usernameText);
        messageElement.appendChild(usernameElement);
    }

    var textElement = document.createElement('p');
    var messageText = document.createTextNode(message.content);
    textElement.appendChild(messageText);

    messageElement.appendChild(textElement);

    messageArea.appendChild(messageElement);
    messageArea.scrollTop = messageArea.scrollHeight;
}


function getAvatarColor(messageSender) {
    var hash = 0;
    for (var i = 0; i < messageSender.length; i++) {
        hash = 31 * hash + messageSender.charCodeAt(i);
    }

    var index = Math.abs(hash % colors.length);
    return colors[index];
}
usernameRegisterForm.addEventListener('submit', connect, true)
usernameForm.addEventListener('submit', connect1, true)
messageForm.addEventListener('submit', send, true)